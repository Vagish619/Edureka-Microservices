package com.vagish.eureka.studentmsloadbalancer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.loadbalancer.core.RoundRobinLoadBalancer;
import org.springframework.cloud.loadbalancer.support.LoadBalancerClientFactory;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class StudentMSServiceLoadBalancerController {

	@Autowired
	LoadBalancerClientFactory clientFactory;

	@Autowired
	RestTemplate restTemplate;

	@GetMapping("/students")
	public String findAllStudents(Model model) {

		// this will connect to eureka server, asks for address details of student
		// service
		// Eureka server will respond with student service details
		RoundRobinLoadBalancer lb = clientFactory.getInstance("STUDENTMS", RoundRobinLoadBalancer.class);

		// load balancer has to choose an instance from the list returne by Eureka
		// serevr
		ServiceInstance instance = lb.choose().block().getServer();
		String host = instance.getHost();
		int port = instance.getPort();

		String URL = "http://" + host + ":" + port + "/students";
		System.out.println("LB-Choosen-URL: " + URL);
		String response = this.restTemplate.getForObject(URL, String.class);

		return response;
	}

	@GetMapping("/students/{apiName}")
	public String studentActions(@PathVariable("apiName") String apiName, Model model) {

		// this will connect to eureka server, asks for address details of student
		// service
		// Eureka server will respond with student service details
		RoundRobinLoadBalancer lb = clientFactory.getInstance("STUDENTMS", RoundRobinLoadBalancer.class);

		// load balancer has to choose an instance from the list returne by Eureka
		// serevr
		ServiceInstance instance = lb.choose().block().getServer();
		String host = instance.getHost();
		int port = instance.getPort();

		String URL = "http://" + host + ":" + port + "/students";
		if (null != apiName && !apiName.isEmpty()) {
			URL = "http://" + host + ":" + port + "/students/" + apiName;
		}

		System.out.println("LB-Choosen-URL: " + URL);
		String response = this.restTemplate.getForObject(URL, String.class);

		return response;
	}
}
