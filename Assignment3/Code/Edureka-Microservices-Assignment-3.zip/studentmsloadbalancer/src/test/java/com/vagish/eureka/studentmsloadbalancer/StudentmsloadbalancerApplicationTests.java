package com.vagish.eureka.studentmsloadbalancer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentmsloadbalancerApplicationTests {

	@Test
	void contextLoads() {
	}

}
