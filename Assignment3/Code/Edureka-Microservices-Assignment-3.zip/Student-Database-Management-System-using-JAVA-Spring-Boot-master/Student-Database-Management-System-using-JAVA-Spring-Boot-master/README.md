# Student-Database-Management-System-using-JAVA-Spring-Boot
In this project, I have worked on a Database Management System for Students where they can manage their courses, reviews and passport details using Spring Boot Web Platform.
