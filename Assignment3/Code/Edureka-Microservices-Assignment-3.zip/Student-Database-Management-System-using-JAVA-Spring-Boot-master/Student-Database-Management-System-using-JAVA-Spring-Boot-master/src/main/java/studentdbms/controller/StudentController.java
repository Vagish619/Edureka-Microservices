package studentdbms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import studentdbms.entity.Student;
import studentdbms.service.StudentService;

@Controller
@RequestMapping("/students")
public class StudentController {
	@Autowired
	private StudentService studentService;

	@GetMapping("")
	public String findAll(Model model) {
		List<Student> students = studentService.findAll();
		model.addAttribute("students", students);
		model.addAttribute("student", new Student());
		return "student-list";
	}

	@GetMapping("/add")
	public String add(Model model) {
		Student theStudent = new Student();
		model.addAttribute("theStudent", theStudent);
		return "student-form";
	}

	@PostMapping("/save")
	public String save(@ModelAttribute("theStudent") Student theStudent) {
		studentService.save(theStudent);
		return "redirect:/students";
	}

	@GetMapping("/{id}")
	public String deleteStudentById(@PathVariable("id") Integer id) {
		studentService.deleteStudentById(id);
		return "redirect:/students";
	}

	@GetMapping("/single/{id}")
	public String getStudentById(@PathVariable Integer id, Model model) {
		Student singleStudent = studentService.getStudentById(id);
		model.addAttribute("singleStudent", singleStudent);
		return "single-student-details";
	}

	@PostMapping("/updateStudent/{id}")
	public String updateStudentName(@PathVariable("id") int id, @ModelAttribute("temp") Student student) {
		Student updatedStudent = studentService.findById(id);
		updatedStudent.setName(student.getName());
		studentService.save(updatedStudent);
		return "redirect:/students";
	}

}
