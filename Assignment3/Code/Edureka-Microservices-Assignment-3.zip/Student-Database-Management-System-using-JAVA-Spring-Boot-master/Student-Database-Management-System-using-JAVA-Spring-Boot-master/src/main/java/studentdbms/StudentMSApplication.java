package studentdbms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

import studentdbms.entity.Student;
import studentdbms.service.StudentService;

@SpringBootApplication
@EnableDiscoveryClient
public class StudentMSApplication implements CommandLineRunner {
	@Autowired
	private StudentService studentService;

	public static void main(String[] args) {

		if (args.length > 0) {
			System.setProperty("server.port", args[0]);
		}
		SpringApplication.run(StudentMSApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Student student = new Student("Vagish");
		studentService.save(student);
		studentService.save(student);
	}

}
