package com.vagish.edureka.registrationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
